Data structures
===============

Metadata
--------

.. doxygenstruct:: Metadata
   :project: deepspeech-c
   :members:

CandidateTranscript
-------------------

.. doxygenstruct:: CandidateTranscript
   :project: deepspeech-c
   :members:

TokenMetadata
-------------

.. doxygenstruct:: TokenMetadata
   :project: deepspeech-c
   :members:
